// src/api/http.js (offline mock)
export const http = {
  async post(url, body) {
    
    await new Promise((r) => setTimeout(r, 500))

    if (url === '/auth/login') {
      
        if (body.username === 'admin' && body.password === '1234') {
        return {
          data: {
            id: 1,
            username: 'admin',
            firstName: 'Local',
            lastName: 'User',
            email: 'admin@example.com',
            token: 'mock-token-123456'
          }
        }
      } else {
        throw new Error('Invalid credentials')
      }
    }

    throw new Error('Unknown endpoint: ' + url)
  }
}
